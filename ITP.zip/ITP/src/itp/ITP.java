/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package itp;

import Interface.Main;



/**
 *
 * @author USER
 */
public class ITP{

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Main m = new Main();
        m.setVisible(true);
        
    }
        
        
        
     
    }
        
        
        
      
        
   

